module problem_statement_18 {
}