package problem_statement_8_1;
public class ThreadCounter {

	public static void main(String args[])

	{

	Counter counter = new Counter(40);

	counter.run();

	}



	}